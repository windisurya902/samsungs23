# discord-post sederhana 
                                   
## source code di permudah sedikit agar lebih mudah di baca.

## • Cara mendapatkan informasi yang di perlukan untuk mengganti pada config 

F12 di browser lalu ke menu 'Network' discord kalian. kirim 1 pesan pada target server dan channel tujuan.

disana terdapat info apa saja yang harus di ganti.

![gambar](https://user-images.githubusercontent.com/72789792/210922863-ff200010-e478-4ea1-991e-811d9ddbbcfb.png)


baca pelan-pelan agar paham.

Terimakasih!

## • Cara pakai

- Install Xampp / termux ( untuk di pc / android )

- download source code pada file ini

- edit dahulu config, dan sesuaikan dengan kebutuhan kalian dan save it

- lalu jalankan dengan cara mengetik : php discord.php


## • CONFIG 

- $auth = "EDIT SENDIRI"; // jangan lupa di ganti

- $X_Super_Properties = "EDIT SENDIRI"; // jangan lupa di ganti

- $cookie = "EDIT SENDIRI"; // jangan lupa di ganti

- $targetServer = "EDIT SENDIRI"; // jangan lupa di ganti

- $targetChannel = "EDIT SENDIRI"; // jangan lupa di ganti

- $isiPesan = "EDIT SENDIRI"; // jangan lupa di ganti

## • Coffee for me ^_^

buy me some coffee!
https://saweria.co/khairulkrhacx

BSC Address : 0x93322E6eccBc8B430c3E635F132e8d0252cC71c9
